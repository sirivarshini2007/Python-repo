'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class father():
    def skills(self):
        print("Dear")
class mother():
    def skills(self):
        print("My dear")
class child(father,mother):
    def skills(self):
        father.skills(self)
        mother.skills(self)
        print("!!")
obj=child()
obj.skills()
        

        