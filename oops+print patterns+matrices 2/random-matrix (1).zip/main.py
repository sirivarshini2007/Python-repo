'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Create a matrix with random numbers
import random
rows=3
cols=3
matrix=[]
for i in range(rows):
    row=[]
    for j in range(cols):
        row.append(random.randint(1,10))
    matrix.append(row)
for row in matrix:
    print(row)