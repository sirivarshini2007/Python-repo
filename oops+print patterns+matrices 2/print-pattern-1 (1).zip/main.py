'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

n=5
i=1
while i<=n:
    print(" "*(n-i)+"*"*(2*i-1))
    i=i+1