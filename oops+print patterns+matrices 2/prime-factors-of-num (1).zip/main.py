'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def prime_factors(num):
    factors=[ ]
    i=2
    while i*i<=num:
        if num%i:
            i=i+1
        else:
            num//=i
            factors.append(i)
    if num>1:
        factors.append(num)
    return factors
numbers=[60,75,90]
for num in numbers:
    print(f"Prime factors of{num}:{prime_factors(num)}")