'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
w=input()
if w=="sunny":
    print("Cricket")
    print("Good")
elif w=="cloudy":
    print("Teddy bear")
    print("ok")
else:
    print("Play with toys")
print("Have a nice day")