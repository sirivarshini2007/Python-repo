'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a=int(input("Enter number of students:"))
b=int(input("Enter number of apples :"))
c=b/2
d=a-b/2
print(f"Number of students who received two apples:{c}")
print(f"Number of students who did not receive apples:{d}")

