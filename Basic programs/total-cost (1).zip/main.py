'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a=int(input("Enter cost of cupcakes in rupees:"))
#1 dollar = 65 rupee
b=a/65
#1 dollar = 100 cents
c=b*100
print(f"Cost in dollars : {b}")
print(f"Cost in cents :{c}")


