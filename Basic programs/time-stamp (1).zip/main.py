'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print("Time stamp1:")
a1=int(input("Enter hours (1):"))
b1=int(input("Enter minutes(1):"))
c1=int(input("Enter seconds(1):"))
print("Time stamp2:")
a2=int(input("Enter hours(2):"))
b2=int(input("Enter minutes(2):"))
c2=int(input("Enter seconds(2):"))
d=c2-c1
print(f"Difference in two time stamp (seconds):{d}")