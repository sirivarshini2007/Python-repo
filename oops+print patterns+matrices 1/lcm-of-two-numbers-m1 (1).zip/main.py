'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a=int(input())
b=int(input())
if (a>b):
    low=a
else:
    low=b
while (1):
    if low%a==0 and low%b==0:
        lcm=low
        break
    low+=1
print("LCM=",lcm)