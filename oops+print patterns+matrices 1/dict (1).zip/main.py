'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
'''mydict={'name':'John','age':30,'city':'Newyork'}
mydict['age']=20
mydict['city']='San Francisco'
print(mydict)'''
mydict={}
a=input("Give name:")
b=int(input("Give age:"))
c=input("Give City:")
mydict['name']=a
mydict['age']=b
mydict['city']=c
print(mydict)