'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a=int(input())
b=int(input())
if(a>b):
    n=a
    d=b
else:
    n=b
    d=a
while(1):
    r=n%d
    if(r==0):
        gcd=d
        break
    n=d
    d=r
print("GCD=",gcd)