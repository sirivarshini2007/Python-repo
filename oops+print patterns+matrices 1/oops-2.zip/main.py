'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
from abc import ABC, abstractmethod
class robo(ABC):
    @abstractmethod
    def sana(self):
        pass
class chitti (robo):
    def sana(self):
        print("Hello")
obj=chitti()
obj.sana()