'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Creating matrix with incremental numbers
rows=3
cols=3
matrix=[]
num=1
for i in range(rows):
    row=[]
    for j in range(cols):
        row.append(num)
        num+=1
    matrix.append(row)
print(matrix)
