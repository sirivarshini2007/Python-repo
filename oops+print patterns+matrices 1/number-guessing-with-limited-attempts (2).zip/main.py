'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Number guessing with limited attempts:
import random
def guess_number_limit():
    target=random.randint(1,10)
    attempts=5
    score=0
    print("Guess the number between 1-50,you have five attempts")
    while attempts>0:
        guess=int(input("Enter the number:"))
        attempts-=1
        if guess>target:
            print("Too high!,try again")
        elif guess<target:
            print("Too low!,try again")
        else:
            print("Correct you won")
            score+=1
            print(f"Your score is :{score}")
            return
        if attempts==0:
            print(f"Out of the attempts ,target={target}")
            return
        print(f"Attempts left:{attempts}")
guess_number_limit()