'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Matrix diagonal sum
matrix1=[[1,2,3],[4,5,6],[7,8,9]]
primary_diagonal_sum=0
secondary_diagonal_sum=0
for i in range(len(matrix1)):
    primary_diagonal_sum+=matrix1[i][i]
    secondary_diagonal_sum+=matrix1[i][len(matrix1)-1-i]
print("Primary diagonal sum:",primary_diagonal_sum)
print("Secondary diagonal sum:",secondary_diagonal_sum)