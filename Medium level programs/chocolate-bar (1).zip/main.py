'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#CHOCOLATE BAR
a=int(input("Enter number of columns :"))
b=int(input("Enter number of rows:"))
c=int(input("Enter number of squares:"))
if a==b and c==4:
    print("YES")
elif a>b and c==2:
    print("YES")
elif b>a and c==2:
    print("YES")
else:
    print("NO")