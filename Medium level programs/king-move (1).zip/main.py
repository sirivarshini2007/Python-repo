'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#KING MOVE
a=int(input("Enter x1:"))
b=int(input("Enter y1:"))
c=int(input("Enter x2:"))
d=int(input("Enter y2:"))
if c==a+1 or c==a-1:
    print("Yes")
elif d==b+1 or d==b-1:
    print("Yes")
elif c==a+1 and d==b+1:
    print("Yes")
elif c==a-1 and d==b-1:
    print("Yes")
elif c==a+1 and d==b-1:
    print("Yes")
elif c==a-1 and d==b+1:
    print("Yes")
else:
    print("No")
