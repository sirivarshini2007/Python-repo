'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

#SLICES#
a=input()
print(a[2])#THIRD CHARACTER#

print(a[-2])#LAST BUTONE CHARACTER#

print(a[0:5])#FIRST FIVE CHARACTERS#

print(a[-2:])#EXCEPT LAST TWO CHARACTER#

print(a[0::2])#EVEN CHARACTERS#

print(a[1::2])#ODD CHARACTERS#

print(a[::-1])#REVERSE OF CHARACTER#

b=a[0::2]#EVEN CHARACTER REVERSAL#
print(b[::-1])

print(len(a))#LENGTH OF STRING#