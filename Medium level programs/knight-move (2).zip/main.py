'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#KNIGHT MOVE
a=int(input("Enter x1:"))
b=int(input("Enter y1:"))
c=int(input("Enter x2:"))
d=int(input("Enter y2:"))
if c==a+1 and d==b+2:
    print("Yes")
elif c==a-1 and d==b+2:
    print("Yes")
elif c==a+1 and d==b-2:
    print("Yes")
elif c==a-1 and d==b-2:
    print("Yes")
elif c==a+2 and d==b+1:
    print("Yes")
elif c==a+2 and d==b-1:
    print("Yes")
elif c==a-2 and d==b+1:
    print("Yes")
elif c==a-2 and d==b-1:
    print("Yes")
else :
    print("NO")









