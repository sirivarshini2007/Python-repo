'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#SPLITTING OF STRING INTO TWO EQUAL HALVES #
a="I AM VERY HAPPY Today"
d=len(a)
print(d)
b=a.split(" ")
print(len(b))
print(b[0::2])
print(b[1::2])
c=d-(d-1)/2
print(c)
print(b[0::2]+b[])

