'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#DICE ROLLER#
import random
def dice_roller():
    score=0
    print("Welcome to dice roller")
    while True:
        roll=input("Enter y/n or quit:").lower()
        if roll=='y':
            print('YOu rolled:',random.randint(1,6))
        elif roll=='n':
            print("Good bye")
            break
        else:
            print("Invalid")
dice_roller()