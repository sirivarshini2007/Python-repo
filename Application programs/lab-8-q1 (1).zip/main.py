'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

# Guess the number
import random
def guess_number():
    print("Welcome to guess the number")
    print("I am thinking to guess the number")
    target_number=random.randint(1,10)
    attempts=0
    while True:
        guess=input("Enter number:")
        if not guess.isdigit():
            print("Enter a valid number:")
            continue
        guess=int(guess)
        attempts+=1
        if guess<target_number:
            print("Too low,Try again!")
        elif guess>target_number:
            print("Too high,Try again")
        else:
            print(f"Congratulations you cleared in{attempts} atempts")
            break
guess_number()