'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
import random
answer=random.randint(1,100)
guesses=0
is_running=True
print("Welcome to python number guessing game")
while is_running:
    print("Enter a number between 1 and 100")
    guess=input()
    if guess.isdigit():
        guess=int(guess)
        guesses+=1
        if guess<=1 and guess>=100:
            print("Invalid input , not in range")
        if guess>answer:
            print("Too high!,Try again")
        elif guess<answer:
            print("Too low!,Try again")
        else:
            print("You won the game")
            print(f"You got correct in{guesses} guesses")
    else:
        print("Invalid input")
        print("Enter a number between the specificed range")
