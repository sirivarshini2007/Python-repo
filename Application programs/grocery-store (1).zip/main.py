'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def grocery_store():
    items=["apple","orange","mango","carrot","onion"]
    sp=[20,30,40,50,60]
    cp=[25,35,45,55,65]
    bill=0
    cost=0
    n=int(input("Enter the day number:"))
    if n==3:
        sp=[price*0.2 for price in sp]
    elif n==4:
        sp=[price*0.3 for price in sp]
    elif n==5:
        sp=[price*0.4 for price in sp]
    elif n==6:
        sp=[price*0.5 for price in sp]
    elif n==7:
        sp=[price*0.6 for price in sp]
    while True:
        c=input("Enter the items you want accordingly:")
        if c=="done":
            break
        selected=c.split(",")
        for item in selected:
            item=item.strip()
            if item not in items:
                print("Invalid")
            else:
                index=items.index(item)
                bill+=sp[index]
                cost+=cp[index]
    print("Total amount:",bill)
    if bill>cost:
        profit=bill-cost
        print(f"You got {profit} amount profit")
    else:
        loss=cost-bill
        print(f"You got {loss} amount loss")
grocery_store()