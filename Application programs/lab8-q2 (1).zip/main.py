'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Rock paper scissors
import random
def rock_paper_scissors():
    choices=['rock','paper','scissor']
    score=0
    print("Welcome to rock paper scissor")
    while True:
        user_input=input("Enter character:").lower()
        if user_input=="quit" :
            print(f"Thanks for playing the game {score} score")
            break
        if user_input not in choices:
            print("Invalid! try again")
            continue
        computer_choice=random.choice(choices)
        print(f"Computer_choice:{computer_choice}")
        if user_input==computer_choice:
            print("It's a tie")
        elif (user_input=='rock' and computer_choice=='scissor')or\
             (user_input=='paper' and computer_choice=='rock')or\
             (user_input=='scissor' and computer_choice=='paper'):
            print("You won!")  
            score+=1
        else:
            print("You lose")
rock_paper_scissors()
    