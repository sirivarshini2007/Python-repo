'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
seats=[[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15],[16,17,18,19,20],[21,22,23,24,25]]
a=input("Enter single or multiple_random or multiple_together seat booking:")
if a=="single":
    b=int(input("Enter seat number:"))
    for i in range(len(seats)):
        for j in range(len(seats[i])):
            if seats[i][j]==b:
                seats[i][j]='B'
for row in seats:
    print(row)

if a=="multiple_random":
    d=input("Enter the seat numbers:")
    c=list(map(int,d.split(",")))
    for i in range(len(seats)):
        for j in range(len(seats[i])):
            for k in range(len(c)):
                if seats[i][j]==c[k]:
                    seats[i][j]='B'
for row in seats:
    print(row)
if a=="multiple_together":
    e=int(input("Enter starting seat number:"))
    f=int(input("Enter ending seat number:"))
    for i in range(len(seats)):
        for j in range(len(seats[i])):
            if seats[i][j]>=e and seats[i][j]<=f:
                seats[i][j]='B'
for row in seats:
    print(row)
