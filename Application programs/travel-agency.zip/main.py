'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

def travel_agency():
    places=["america","Japan","korea","russia","switzerland","newzealand","nileriver","nigeriafalls","uk"]
    days=[4,5,6,3,2,7,9,10,12]
    budget=[200000,300000,400000,500000,600000,700000,800000,900000,100000]
    price=0
    while True:
        a=int(input("Enter number of tickets"))
        for i in range(len(budget)):
            if a==2:
                price+=budget[i]
            elif a>=2 and a<=5:
                price+=budget[i]*0.05
            else:
                price+=budget[i]*0.1
        print(places)
        print(budget)
        b=input("Select a place from above")
        if b not in places:
            print("Sorry! we donot have that place")
            break
        c=int(input("Enter your budget according to the above list:"))
        if c<10000:
            print("Not sufficient amount")
            break
        if b=="america" and c==200000:
            print("Days required are:",days[0])
            print("cost is:",price)
        elif b=="Japan" and c==300000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="korea" and c==400000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="russia" and c==500000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="switzerland" and c==600000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="newzealand" and c==700000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="nileriver" and c==800000:
            print("Days required are:",days[1])
            print("cost is:",price)
        elif b=="nigeriafalls" and c==900000:
            print("Days required are:",days[1])
            print("cost is:",price)
        else:
            print("Days required are:",days[1])
            print("cost is:",price)
travel_agency()
        
        
        
            
            