'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

def ATM_machine():
    choice=["withdrawal","deposit","changepin","checkbalance","Exit"]
    pin=1234
    intial_balance=10000
    while True:
        print("Welcome to bank")
        print(choice)
        user_choice=input("Enter one from above choices:")
        if user_choice not in choice:
            print("Invalid")
        if user_choice=="withdrawal":
            a=int(input("Enter amount to be withdrawn"))
            if (a>intial_balance):
                print("Insufficient funds")
            else:
                intial_balance-=a
                print(f"{a} amount is withdrawn")
        elif user_choice=="deposit":
            b=int(input("Enter amount to be deposited"))
            intial_balance+=b
            print(f"{b} amount is deposited")
        elif user_choice=="checkbalance":
            print(intial_balance)
        elif user_choice=="changepin":
            c=input("Enter new pin:")
            if len(c)>4:
                print("Invalid pin")
            else:
                print("New pin:",c)
        else:
            print("Thankyou for visiting the bank")
ATM_machine()
            