'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Magic 8 ball game
import random
def magic_8_ball():
    responses=['Yes definitely!','No way!','May be','Ask again later','It is certain','very doubtful','Outlook not so good','Signs point to yes']
    print("Welcome to magic 8 ball game")
    while True:
        question=input("Ask a yes or no question (or quit to exit):")
        if question.lower()=='quit':
            break
        print(random.choice(responses))
magic_8_ball()